# Acolhe Sênior

Sistema de gestão de pacientes para casas de repouso.

## Como executar

```bash
npm install
npm run seed
npm start
```

Acesse: http://localhost:3000/Login/index.HTML

## Credenciais de demo (senha: `123456`)

| E-mail | Cargo | Escopo |
|---|---|---|
| `admin@acolhesenior.com` | Administrador | Acesso global — vê e gerencia **todas** as unidades |
| `diretor@acolhesenior.com` | Diretor | Apenas **Residencial Vida Plena** — gerencia cuidadores locais |
| `joao@acolhesenior.com` | Diretor | Apenas **Lar São Francisco** |
| `cuidador@acolhesenior.com` | Cuidador | Apenas **Casa Repouso Horizonte** — sem gestão de usuários |

## Modelo de permissões

- **Administrador:** `unidade_id = null`, visualiza todas as unidades na Home, acessa pacientes de qualquer unidade selecionada e gerencia cuidadores/administradores globalmente.
- **Diretor:** vinculado a uma unidade, gerencia apenas **cuidadores** da sua unidade e pacientes locais.
- **Cuidador:** vinculado a uma unidade, visualiza pacientes e registra observações.
