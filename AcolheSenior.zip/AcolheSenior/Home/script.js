document.addEventListener("DOMContentLoaded", async () => {
    const inputBusca = document.getElementById("inputBusca");
    const cardsGrid = document.getElementById("cardsGrid");
    const loadingMsg = document.getElementById("loadingMsg");
    const modal = document.getElementById("modalConfirmacao");
    const btnConfirmar = document.getElementById("btnConfirmar");
    const btnCancelar = document.getElementById("btnCancelar");
    let contextoTemp = {};
    let unidades = [];

    exibirNomeUsuario();
    configurarTema();
    configurarLogout();

    const cargoLabels = {
        diretor: "Diretor",
        administrador: "Administrador",
        cuidador: "Cuidador",
    };

    function entrarUnidade(unidade) {
        const cargo = unidade.cargo;
        localStorage.setItem("userContext", JSON.stringify({
            unidade_id: unidade.id,
            unidade: unidade.nome,
            cargo,
        }));
        localStorage.setItem("cargoUsuario", cargo);
        localStorage.setItem("unidadeAtual", JSON.stringify({
            id: unidade.id,
            nome: unidade.nome,
        }));
        window.location.href = "/Pacientes/index.HTML";
    }

    try {
        unidades = await apiFetch("/api/unidades");
        loadingMsg.style.display = "none";

        if (unidades.length === 1) {
            entrarUnidade(unidades[0]);
            return;
        }

        renderCards(unidades);
    } catch {
        loadingMsg.textContent = "Erro ao carregar unidades. Faça login novamente.";
        setTimeout(() => { window.location.href = "/Login/index.HTML"; }, 2000);
        return;
    }

    function renderCards(lista) {
        cardsGrid.innerHTML = "";
        lista.forEach((u) => {
            const card = document.createElement("div");
            card.className = `card card-${u.cargo}`;
            card.dataset.unidadeId = u.id;
            card.dataset.unidade = u.nome;
            card.dataset.cargo = u.cargo;
            card.innerHTML = `
                <strong>${u.nome}</strong>
                <span class="badge">${cargoLabels[u.cargo] || u.cargo}</span>
            `;
            card.addEventListener("click", () => {
                contextoTemp = { unidade_id: u.id, unidade: u.nome, cargo: u.cargo };
                document.getElementById("modalTexto").innerHTML =
                    `Deseja entrar na unidade <strong>${u.nome}</strong> como <strong>${cargoLabels[u.cargo]}</strong>?`;
                modal.style.display = "flex";
            });
            cardsGrid.appendChild(card);
        });
    }

    inputBusca.addEventListener("input", () => {
        const termo = inputBusca.value.toLowerCase().trim();
        document.querySelectorAll(".card").forEach((card) => {
            const unidade = card.dataset.unidade.toLowerCase();
            const cargo = card.dataset.cargo.toLowerCase();
            const match = unidade.includes(termo) || (termo.length >= 3 && cargo.includes(termo));
            card.style.display = match ? "flex" : "none";
        });
    });

    btnConfirmar.addEventListener("click", () => {
        entrarUnidade({
            id: contextoTemp.unidade_id,
            nome: contextoTemp.unidade,
            cargo: contextoTemp.cargo,
        });
    });

    btnCancelar.addEventListener("click", () => { modal.style.display = "none"; });
    window.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
});
