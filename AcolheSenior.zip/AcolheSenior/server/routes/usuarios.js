const bcrypt = require("bcryptjs");
const { isGlobal, canManageUsuarios, canAccessUnidade } = require("../permissions");

module.exports = function createUsuariosRoutes(db) {
  const router = require("express").Router();

  function requireAuth(req, res, next) {
    if (!req.session.usuario) return res.status(401).json({ erro: "Não autenticado." });
    next();
  }

  function requireManager(req, res, next) {
    if (!canManageUsuarios(req.session.usuario.cargo)) {
      return res.status(403).json({ erro: "Acesso restrito a diretores e administradores." });
    }
    next();
  }

  function getUsuarioById(id) {
    return db.prepare("SELECT id, nome, email, cargo, telefone, status, unidade_id FROM usuarios WHERE id = ?").get(id);
  }

  router.get("/", requireAuth, requireManager, (req, res) => {
    const usuario = req.session.usuario;
    const { unidade_id } = req.query;

    if (usuario.cargo === "diretor") {
      const sql = "SELECT id, nome, email, cargo, telefone, status, unidade_id FROM usuarios WHERE cargo = 'cuidador' AND unidade_id = ? ORDER BY nome";
      return res.json(db.prepare(sql).all(usuario.unidade_id));
    }

    let sql = "SELECT id, nome, email, cargo, telefone, status, unidade_id FROM usuarios WHERE cargo IN ('cuidador', 'administrador')";
    const params = [];

    if (unidade_id) {
      sql += " AND unidade_id = ?";
      params.push(unidade_id);
    }

    sql += " ORDER BY nome";
    res.json(db.prepare(sql).all(...params));
  });

  router.post("/", requireAuth, requireManager, (req, res) => {
    const usuario = req.session.usuario;
    const { nome, email, cargo, telefone, status, senha, unidade_id } = req.body;

    if (!nome || !email || !cargo || !senha) {
      return res.status(400).json({ erro: "Nome, e-mail, cargo e senha são obrigatórios." });
    }

    if (usuario.cargo === "diretor") {
      if (cargo !== "cuidador") {
        return res.status(403).json({ erro: "Diretores podem cadastrar apenas cuidadores." });
      }
      if (Number(unidade_id) !== Number(usuario.unidade_id)) {
        return res.status(403).json({ erro: "Diretores só podem cadastrar cuidadores da própria unidade." });
      }
    } else if (!["cuidador", "administrador"].includes(cargo)) {
      return res.status(400).json({ erro: "Cargo inválido." });
    }

    const existente = db.prepare("SELECT id FROM usuarios WHERE email = ?").get(email);
    if (existente) return res.status(409).json({ erro: "E-mail já cadastrado." });

    const unidadeFinal = usuario.cargo === "diretor"
      ? usuario.unidade_id
      : (unidade_id || null);

    const result = db.prepare(
      "INSERT INTO usuarios (nome, email, senha, cargo, telefone, status, unidade_id) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run(nome, email, bcrypt.hashSync(senha, 10), cargo, telefone || null, status || "ativo", unidadeFinal);

    res.status(201).json({ id: result.lastInsertRowid, mensagem: "Usuário criado com sucesso." });
  });

  router.put("/:id", requireAuth, requireManager, (req, res) => {
    const usuario = req.session.usuario;
    const alvo = getUsuarioById(req.params.id);

    if (!alvo) return res.status(404).json({ erro: "Usuário não encontrado." });

    if (usuario.cargo === "diretor") {
      if (alvo.cargo !== "cuidador" || Number(alvo.unidade_id) !== Number(usuario.unidade_id)) {
        return res.status(403).json({ erro: "Sem permissão para editar este usuário." });
      }
      if (req.body.cargo && req.body.cargo !== "cuidador") {
        return res.status(403).json({ erro: "Diretores podem gerenciar apenas cuidadores." });
      }
    }

    const { nome, email, cargo, telefone, status, senha } = req.body;

    const sets = [];
    const values = [];
    if (nome) { sets.push("nome = ?"); values.push(nome); }
    if (email) { sets.push("email = ?"); values.push(email); }
    if (cargo) { sets.push("cargo = ?"); values.push(cargo); }
    if (telefone !== undefined) { sets.push("telefone = ?"); values.push(telefone); }
    if (status) { sets.push("status = ?"); values.push(status); }
    if (senha) { sets.push("senha = ?"); values.push(bcrypt.hashSync(senha, 10)); }

    if (sets.length === 0) return res.status(400).json({ erro: "Nenhum campo para atualizar." });

    values.push(req.params.id);
    db.prepare(`UPDATE usuarios SET ${sets.join(", ")} WHERE id = ?`).run(...values);
    res.json({ mensagem: "Usuário atualizado com sucesso." });
  });

  router.delete("/:id", requireAuth, requireManager, (req, res) => {
    const usuario = req.session.usuario;
    const alvo = getUsuarioById(req.params.id);

    if (!alvo) return res.status(404).json({ erro: "Usuário não encontrado." });

    if (usuario.cargo === "diretor") {
      if (alvo.cargo !== "cuidador" || Number(alvo.unidade_id) !== Number(usuario.unidade_id)) {
        return res.status(403).json({ erro: "Sem permissão para excluir este usuário." });
      }
    }

    db.prepare("DELETE FROM usuarios WHERE id = ?").run(req.params.id);
    res.json({ mensagem: "Usuário excluído." });
  });

  return router;
};
