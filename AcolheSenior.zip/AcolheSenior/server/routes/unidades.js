const { isGlobal } = require("../permissions");

module.exports = function createUnidadesRoutes(db) {
  const router = require("express").Router();

  function requireAuth(req, res, next) {
    if (!req.session.usuario) return res.status(401).json({ erro: "Não autenticado." });
    next();
  }

  router.get("/", requireAuth, (req, res) => {
    const { cargo, unidade_id } = req.session.usuario;

    let unidades;
    if (isGlobal(cargo)) {
      unidades = db.prepare("SELECT * FROM unidades ORDER BY nome").all();
    } else {
      unidades = db.prepare("SELECT * FROM unidades WHERE id = ?").all(unidade_id);
    }

    res.json(unidades.map((u) => ({ ...u, cargo })));
  });

  return router;
};
