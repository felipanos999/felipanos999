const { canAccessUnidade, canWritePacientes } = require("../permissions");

module.exports = function createPacientesRoutes(db) {
  const router = require("express").Router();

  function requireAuth(req, res, next) {
    if (!req.session.usuario) return res.status(401).json({ erro: "Não autenticado." });
    next();
  }

  function calcularIdade(dataNascimento) {
    if (!dataNascimento) return "—";
    const nasc = new Date(dataNascimento);
    const hoje = new Date();
    let idade = hoje.getFullYear() - nasc.getFullYear();
    const m = hoje.getMonth() - nasc.getMonth();
    if (m < 0 || (m === 0 && hoje.getDate() < nasc.getDate())) idade--;
    return `${idade} anos`;
  }

  function formatarDataBR(data) {
    if (!data) return "—";
    const [y, m, d] = data.split("-");
    return `${d}/${m}/${y}`;
  }

  router.get("/", requireAuth, (req, res) => {
    const { unidade_id, busca, quarto, turno } = req.query;
    if (!unidade_id) return res.status(400).json({ erro: "unidade_id é obrigatório." });

    if (!canAccessUnidade(req.session.usuario, unidade_id)) {
      return res.status(403).json({ erro: "Sem permissão para acessar esta unidade." });
    }

    let sql = "SELECT * FROM pacientes WHERE unidade_id = ?";
    const params = [unidade_id];

    if (busca) { sql += " AND nome LIKE ?"; params.push(`%${busca}%`); }
    if (quarto) { sql += " AND quarto = ?"; params.push(quarto); }
    if (turno) { sql += " AND turno = ?"; params.push(turno); }

    sql += " ORDER BY nome";

    const pacientes = db.prepare(sql).all(...params).map((p) => ({
      ...p,
      idade: calcularIdade(p.data_nascimento),
      data_nascimento_fmt: formatarDataBR(p.data_nascimento),
    }));

    res.json(pacientes);
  });

  router.get("/filtros", requireAuth, (req, res) => {
    const { unidade_id } = req.query;
    if (!unidade_id) return res.status(400).json({ erro: "unidade_id é obrigatório." });

    if (!canAccessUnidade(req.session.usuario, unidade_id)) {
      return res.status(403).json({ erro: "Sem permissão para acessar esta unidade." });
    }

    const quartos = db
      .prepare("SELECT DISTINCT quarto FROM pacientes WHERE unidade_id = ? AND quarto IS NOT NULL ORDER BY quarto")
      .all(unidade_id).map((r) => r.quarto);

    const turnos = db
      .prepare("SELECT DISTINCT turno FROM pacientes WHERE unidade_id = ? AND turno IS NOT NULL ORDER BY turno")
      .all(unidade_id).map((r) => r.turno);

    res.json({ quartos, turnos });
  });

  router.get("/:id", requireAuth, (req, res) => {
    const paciente = db.prepare("SELECT * FROM pacientes WHERE id = ?").get(req.params.id);
    if (!paciente) return res.status(404).json({ erro: "Paciente não encontrado." });

    if (!canAccessUnidade(req.session.usuario, paciente.unidade_id)) {
      return res.status(403).json({ erro: "Sem permissão para acessar este paciente." });
    }

    const contatos = db.prepare("SELECT * FROM contatos_emergencia WHERE paciente_id = ?").all(paciente.id);
    const observacoes = db.prepare("SELECT * FROM observacoes WHERE paciente_id = ? ORDER BY criado_em DESC").all(paciente.id);

    res.json({
      ...paciente,
      idade: calcularIdade(paciente.data_nascimento),
      data_nascimento_fmt: formatarDataBR(paciente.data_nascimento),
      contatos,
      observacoes,
    });
  });

  router.post("/", requireAuth, (req, res) => {
    const usuario = req.session.usuario;
    if (!canWritePacientes(usuario.cargo)) {
      return res.status(403).json({ erro: "Sem permissão para cadastrar pacientes." });
    }

    const {
      matricula, nome, cpf, rg, data_nascimento, sexo, quarto, turno,
      cep, rua, numero, complemento, bairro, cidade, estado, foto_path,
      condicoes_saude, grau_dependencia, medicacoes, alergias, plano_saude,
      mobilidade, recomendacoes, historico_clinico, unidade_id, contatos,
    } = req.body;

    if (!matricula || !nome || !unidade_id) {
      return res.status(400).json({ erro: "Matrícula, nome e unidade são obrigatórios." });
    }

    if (!canAccessUnidade(usuario, unidade_id)) {
      return res.status(403).json({ erro: "Sem permissão para cadastrar pacientes nesta unidade." });
    }

    const existente = db.prepare("SELECT id FROM pacientes WHERE matricula = ?").get(matricula);
    if (existente) return res.status(409).json({ erro: "Matrícula já cadastrada." });

    const result = db.prepare(`
      INSERT INTO pacientes (
        matricula, nome, cpf, rg, data_nascimento, sexo, quarto, turno,
        cep, rua, numero, complemento, bairro, cidade, estado, foto_path,
        condicoes_saude, grau_dependencia, medicacoes, alergias, plano_saude,
        mobilidade, recomendacoes, historico_clinico, unidade_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      matricula, nome, cpf, rg, data_nascimento, sexo, quarto, turno,
      cep, rua, numero, complemento, bairro, cidade, estado, foto_path,
      condicoes_saude, grau_dependencia, medicacoes, alergias, plano_saude,
      mobilidade, recomendacoes, historico_clinico, unidade_id
    );

    const pacienteId = result.lastInsertRowid;

    if (contatos && contatos.length > 0) {
      const insertContato = db.prepare(
        "INSERT INTO contatos_emergencia (paciente_id, parentesco, nome, telefone, cpf, rg) VALUES (?, ?, ?, ?, ?, ?)"
      );
      for (const c of contatos) {
        insertContato.run(pacienteId, c.parentesco, c.nome, c.telefone, c.cpf, c.rg);
      }
    }

    res.status(201).json({ id: pacienteId, mensagem: "Paciente cadastrado com sucesso." });
  });

  router.put("/:id", requireAuth, (req, res) => {
    const usuario = req.session.usuario;
    if (!canWritePacientes(usuario.cargo)) {
      return res.status(403).json({ erro: "Sem permissão para editar pacientes." });
    }

    const existente = db.prepare("SELECT * FROM pacientes WHERE id = ?").get(req.params.id);
    if (!existente) return res.status(404).json({ erro: "Paciente não encontrado." });

    if (!canAccessUnidade(usuario, existente.unidade_id)) {
      return res.status(403).json({ erro: "Sem permissão para editar pacientes desta unidade." });
    }

    const campos = [
      "matricula", "nome", "cpf", "rg", "data_nascimento", "sexo", "quarto", "turno",
      "cep", "rua", "numero", "complemento", "bairro", "cidade", "estado", "foto_path",
      "condicoes_saude", "grau_dependencia", "medicacoes", "alergias", "plano_saude",
      "mobilidade", "recomendacoes", "historico_clinico",
    ];

    const sets = [];
    const values = [];
    for (const c of campos) {
      if (req.body[c] !== undefined) { sets.push(`${c} = ?`); values.push(req.body[c]); }
    }

    if (sets.length === 0) return res.status(400).json({ erro: "Nenhum campo para atualizar." });

    values.push(req.params.id);
    db.prepare(`UPDATE pacientes SET ${sets.join(", ")} WHERE id = ?`).run(...values);
    res.json({ mensagem: "Paciente atualizado com sucesso." });
  });

  router.post("/:id/observacoes", requireAuth, (req, res) => {
    const { texto } = req.body;
    if (!texto || !texto.trim()) return res.status(400).json({ erro: "Texto da observação é obrigatório." });

    const paciente = db.prepare("SELECT id, unidade_id FROM pacientes WHERE id = ?").get(req.params.id);
    if (!paciente) return res.status(404).json({ erro: "Paciente não encontrado." });

    if (!canAccessUnidade(req.session.usuario, paciente.unidade_id)) {
      return res.status(403).json({ erro: "Sem permissão para registrar observações neste paciente." });
    }

    const result = db.prepare(
      "INSERT INTO observacoes (paciente_id, texto, criado_por) VALUES (?, ?, ?)"
    ).run(req.params.id, texto.trim(), req.session.usuario.nome);

    const obs = db.prepare("SELECT * FROM observacoes WHERE id = ?").get(result.lastInsertRowid);
    res.status(201).json(obs);
  });

  return router;
};
