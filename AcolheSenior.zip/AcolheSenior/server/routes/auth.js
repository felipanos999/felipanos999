const bcrypt = require("bcryptjs");

module.exports = function createAuthRoutes(db) {
  const router = require("express").Router();

  router.post("/login", (req, res) => {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({ erro: "E-mail e senha são obrigatórios." });
    }

    const usuario = db
      .prepare("SELECT * FROM usuarios WHERE email = ? AND status = 'ativo'")
      .get(email);

    if (!usuario || !bcrypt.compareSync(senha, usuario.senha)) {
      return res.status(401).json({ erro: "E-mail ou senha inválidos." });
    }

    req.session.usuario = {
      id: usuario.id,
      nome: usuario.nome,
      email: usuario.email,
      cargo: usuario.cargo,
      unidade_id: usuario.unidade_id,
    };

    res.json(req.session.usuario);
  });

  router.post("/logout", (req, res) => {
    req.session.destroy(() => res.json({ ok: true }));
  });

  router.get("/me", (req, res) => {
    if (!req.session.usuario) {
      return res.status(401).json({ erro: "Não autenticado." });
    }
    res.json(req.session.usuario);
  });

  return router;
};
