module.exports = function createObservacoesRoutes(db) {
  const router = require("express").Router();

  function requireAuth(req, res, next) {
    if (!req.session.usuario) return res.status(401).json({ erro: "Não autenticado." });
    next();
  }

  router.put("/:id", requireAuth, (req, res) => {
    const cargo = req.session.usuario.cargo;
    if (!["diretor", "administrador"].includes(cargo)) {
      return res.status(403).json({ erro: "Sem permissão para editar observações." });
    }

    const { texto } = req.body;
    if (!texto || !texto.trim()) return res.status(400).json({ erro: "Texto da observação é obrigatório." });

    const obs = db.prepare("SELECT * FROM observacoes WHERE id = ?").get(req.params.id);
    if (!obs) return res.status(404).json({ erro: "Observação não encontrada." });

    db.prepare(
      "UPDATE observacoes SET texto = ?, editado_por = ?, editado_em = datetime('now') WHERE id = ?"
    ).run(texto.trim(), req.session.usuario.nome, req.params.id);

    res.json(db.prepare("SELECT * FROM observacoes WHERE id = ?").get(req.params.id));
  });

  router.delete("/:id", requireAuth, (req, res) => {
    const cargo = req.session.usuario.cargo;
    if (!["diretor", "administrador"].includes(cargo)) {
      return res.status(403).json({ erro: "Sem permissão para excluir observações." });
    }

    const obs = db.prepare("SELECT id FROM observacoes WHERE id = ?").get(req.params.id);
    if (!obs) return res.status(404).json({ erro: "Observação não encontrada." });

    db.prepare("DELETE FROM observacoes WHERE id = ?").run(req.params.id);
    res.json({ mensagem: "Observação excluída." });
  });

  return router;
};
