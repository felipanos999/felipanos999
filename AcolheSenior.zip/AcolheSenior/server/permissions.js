function isGlobal(cargo) {
  return cargo === "administrador";
}

function canAccessUnidade(usuario, unidadeId) {
  if (isGlobal(usuario.cargo)) return true;
  if (usuario.unidade_id == null || unidadeId == null) return false;
  return Number(usuario.unidade_id) === Number(unidadeId);
}

function canManageUsuarios(cargo) {
  return ["diretor", "administrador"].includes(cargo);
}

function canWritePacientes(cargo) {
  return ["diretor", "administrador"].includes(cargo);
}

function canEditObservacoes(cargo) {
  return ["diretor", "administrador"].includes(cargo);
}

module.exports = {
  isGlobal,
  canAccessUnidade,
  canManageUsuarios,
  canWritePacientes,
  canEditObservacoes,
};
