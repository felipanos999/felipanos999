const bcrypt = require("bcryptjs");
const { initDb } = require("./db");

async function seed() {
  const db = await initDb();
  const SENHA = bcrypt.hashSync("123456", 10);

  db.exec("DELETE FROM observacoes");
  db.exec("DELETE FROM contatos_emergencia");
  db.exec("DELETE FROM pacientes");
  db.exec("DELETE FROM usuarios");
  db.exec("DELETE FROM unidades");

  const insertUnidade = db.prepare("INSERT INTO unidades (nome, endereco, telefone) VALUES (?, ?, ?)");
  const insertUsuario = db.prepare(
    "INSERT INTO usuarios (nome, email, senha, cargo, telefone, status, unidade_id) VALUES (?, ?, ?, ?, ?, ?, ?)"
  );
  const insertPaciente = db.prepare(`
    INSERT INTO pacientes (
      matricula, nome, cpf, rg, data_nascimento, sexo, quarto, turno,
      cep, rua, numero, complemento, bairro, cidade, estado, foto_path,
      condicoes_saude, grau_dependencia, medicacoes, alergias, plano_saude,
      mobilidade, recomendacoes, historico_clinico, unidade_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertContato = db.prepare(
    "INSERT INTO contatos_emergencia (paciente_id, parentesco, nome, telefone, cpf, rg) VALUES (?, ?, ?, ?, ?, ?)"
  );
  const insertObs = db.prepare(
    "INSERT INTO observacoes (paciente_id, texto, criado_por, criado_em) VALUES (?, ?, ?, ?)"
  );

  const unidades = [
    ["Residencial Vida Plena", "Av. Paulista, 1000 - São Paulo/SP", "(11) 3456-7890"],
    ["Lar São Francisco", "Rua das Flores, 250 - Campinas/SP", "(19) 3344-5566"],
    ["Casa Repouso Horizonte", "Alameda Verde, 88 - Santos/SP", "(13) 3222-1100"],
  ];

  const unidadeIds = unidades.map((u) => insertUnidade.run(...u).lastInsertRowid);

  insertUsuario.run("Ana Paula Ferreira", "admin@acolhesenior.com", SENHA, "administrador", "(11) 99999-0002", "ativo", null);
  insertUsuario.run("Maria Santos", "diretor@acolhesenior.com", SENHA, "diretor", "(11) 99999-0001", "ativo", unidadeIds[0]);
  insertUsuario.run("Carlos Eduardo Lima", "cuidador@acolhesenior.com", SENHA, "cuidador", "(11) 99999-0003", "ativo", unidadeIds[2]);
  insertUsuario.run("Fernanda Costa", "fernanda@acolhesenior.com", SENHA, "cuidador", "(11) 98888-2222", "ativo", unidadeIds[0]);
  insertUsuario.run("João Pereira", "joao@acolhesenior.com", SENHA, "diretor", "(11) 97777-3333", "ativo", unidadeIds[1]);

  const paciente1 = insertPaciente.run(
    "20240001", "Beatriz Oliveira Lima", "000.000.000-00", "00.000.000-0",
    "1945-03-12", "Feminino", "Quarto 12A", "Tarde",
    "01310-100", "Av. Paulista", "100", "Apto 21", "Bela Vista", "São Paulo", "SP",
    "paciente_feminino.png", "Alzheimer, Hipertensão", "Moderado",
    "Donepezila, Losartana", "Dipirona", "Unimed", "Cadeira de rodas",
    "Ambiente calmo, rotina fixa de horários.", "Episódio de desorientação em março/2024.",
    unidadeIds[0]
  ).lastInsertRowid;

  const paciente2 = insertPaciente.run(
    "20240002", "Pedro Gabriel Costa Silva", "111.111.111-11", "11.111.111-1",
    "1938-07-05", "Masculino", "Quarto 08B", "Integral",
    "04538-132", "Rua Funchal", "418", "—", "Vila Olímpia", "São Paulo", "SP",
    "paciente_masculino.png", "Diabetes tipo 2, Artrite", "Leve",
    "Metformina", "Nenhuma conhecida", "Bradesco Saúde", "Deambula com bengala",
    "Monitorar glicemia antes das refeições.", "Sem episódios críticos registrados.",
    unidadeIds[0]
  ).lastInsertRowid;

  insertContato.run(paciente1, "Filha", "Juliana Lima", "(11) 98765-4321", "222.222.222-22", "22.222.222-2");
  insertContato.run(paciente2, "Filho", "Ricardo Silva", "(11) 91234-5678", "333.333.333-33", "33.333.333-3");
  insertObs.run(paciente1, "Hoje manteve boa orientação durante o almoço.", "Carlos Eduardo Lima", "2024-05-10 14:22:00");

  console.log("Banco populado com sucesso!");
  console.log("");
  console.log("Credenciais (senha: 123456):");
  console.log("  admin@acolhesenior.com       → Administrador (acesso global, todas unidades)");
  console.log("  diretor@acolhesenior.com     → Diretor (Residencial Vida Plena)");
  console.log("  joao@acolhesenior.com        → Diretor (Lar São Francisco)");
  console.log("  cuidador@acolhesenior.com    → Cuidador (Casa Repouso Horizonte)");
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
