const express = require("express");
const session = require("express-session");
const cors = require("cors");
const path = require("path");
const { initDb } = require("./db");

async function start() {
  const db = await initDb();

  const authRoutes = require("./routes/auth")(db);
  const unidadesRoutes = require("./routes/unidades")(db);
  const pacientesRoutes = require("./routes/pacientes")(db);
  const observacoesRoutes = require("./routes/observacoes")(db);
  const usuariosRoutes = require("./routes/usuarios")(db);

  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(cors({ origin: true, credentials: true }));
  app.use(express.json({ limit: "10mb" }));
  app.use(
    session({
      secret: "acolhe-senior-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { maxAge: 24 * 60 * 60 * 1000 },
    })
  );

  app.use("/api/auth", authRoutes);
  app.use("/api/unidades", unidadesRoutes);
  app.use("/api/pacientes", pacientesRoutes);
  app.use("/api/observacoes", observacoesRoutes);
  app.use("/api/usuarios", usuariosRoutes);

  app.use(express.static(path.join(__dirname, "..")));

  app.get("/", (_req, res) => {
    res.redirect("/Login/index.HTML");
  });

  app.listen(PORT, () => {
    console.log(`Acolhe Sênior rodando em http://localhost:${PORT}`);
  });
}

start().catch((err) => {
  console.error("Erro ao iniciar servidor:", err);
  process.exit(1);
});
