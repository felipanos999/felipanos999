const initSqlJs = require("sql.js");
const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "acolhe_senior.db");

let db = null;

function saveDb() {
  if (!db) return;
  fs.writeFileSync(DB_PATH, Buffer.from(db.export()));
}

class Statement {
  constructor(database, sql) {
    this.database = database;
    this.sql = sql;
  }

  get(...params) {
    const stmt = this.database.prepare(this.sql);
    try {
      if (params.length) stmt.bind(params);
      if (stmt.step()) return stmt.getAsObject();
      return undefined;
    } finally {
      stmt.free();
    }
  }

  all(...params) {
    const stmt = this.database.prepare(this.sql);
    const rows = [];
    try {
      if (params.length) stmt.bind(params);
      while (stmt.step()) rows.push(stmt.getAsObject());
      return rows;
    } finally {
      stmt.free();
    }
  }

  run(...params) {
    const stmt = this.database.prepare(this.sql);
    try {
      if (params.length) stmt.bind(params);
      stmt.step();
      const idResult = this.database.exec("SELECT last_insert_rowid() as id");
      saveDb();
      return {
        lastInsertRowid: idResult[0]?.values[0]?.[0] ?? 0,
        changes: this.database.getRowsModified(),
      };
    } finally {
      stmt.free();
    }
  }
}

function createWrapper(database) {
  return {
    prepare(sql) {
      return new Statement(database, sql);
    },
    exec(sql) {
      database.run(sql);
      saveDb();
    },
  };
}

function initSchema(wrapper) {
  wrapper.exec(`
    CREATE TABLE IF NOT EXISTS unidades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      endereco TEXT,
      telefone TEXT
    );

    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      senha TEXT NOT NULL,
      cargo TEXT NOT NULL,
      telefone TEXT,
      status TEXT DEFAULT 'ativo',
      unidade_id INTEGER REFERENCES unidades(id)
    );

    CREATE TABLE IF NOT EXISTS pacientes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      matricula TEXT UNIQUE NOT NULL,
      nome TEXT NOT NULL,
      cpf TEXT, rg TEXT, data_nascimento TEXT, sexo TEXT,
      quarto TEXT, turno TEXT, cep TEXT, rua TEXT, numero TEXT,
      complemento TEXT, bairro TEXT, cidade TEXT, estado TEXT,
      foto_path TEXT, condicoes_saude TEXT, grau_dependencia TEXT,
      medicacoes TEXT, alergias TEXT, plano_saude TEXT, mobilidade TEXT,
      recomendacoes TEXT, historico_clinico TEXT,
      unidade_id INTEGER REFERENCES unidades(id),
      criado_em TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS contatos_emergencia (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
      parentesco TEXT, nome TEXT, telefone TEXT, cpf TEXT, rg TEXT
    );

    CREATE TABLE IF NOT EXISTS observacoes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      paciente_id INTEGER REFERENCES pacientes(id) ON DELETE CASCADE,
      texto TEXT NOT NULL, criado_por TEXT,
      criado_em TEXT DEFAULT (datetime('now')),
      editado_por TEXT, editado_em TEXT
    );
  `);
}

async function initDb() {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    db = new SQL.Database(fs.readFileSync(DB_PATH));
  } else {
    db = new SQL.Database();
  }

  const wrapper = createWrapper(db);
  initSchema(wrapper);
  return wrapper;
}

module.exports = { initDb };
