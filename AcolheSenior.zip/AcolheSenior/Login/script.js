document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("loginForm");
    const msg = document.getElementById("msg");

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        const email = document.getElementById("email").value;
        const senha = document.getElementById("password").value;

        try {
            const usuario = await apiFetch("/api/auth/login", {
                method: "POST",
                body: JSON.stringify({ email, senha }),
            });

            salvarUsuario(usuario);
            msg.textContent = "Login realizado com sucesso! Redirecionando...";
            msg.className = "msg msg-sucesso";

            setTimeout(() => {
                window.location.href = "/Home/index.HTML";
            }, 1000);
        } catch (err) {
            msg.textContent = err.message || "E-mail ou senha inválidos.";
            msg.className = "msg msg-erro";
        }
    });
});
