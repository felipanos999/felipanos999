document.addEventListener("DOMContentLoaded", async () => {
    const cargoLogado = localStorage.getItem("cargoUsuario") || "";
    const unidade = obterUnidadeAtual();
    const cargosPermitidos = ["diretor", "administrador"];
    const isDiretor = cargoLogado === "diretor";

    exibirNomeUsuario();
    configurarTema();
    configurarLogout();
    configurarSubNav();

    if (!cargosPermitidos.includes(cargoLogado)) {
        document.getElementById("conteudoPrincipal").style.display = "none";
        document.getElementById("acessoNegado").style.display = "block";
        return;
    }

    const tbody = document.getElementById("tbodyUsuarios");
    const emptyMsg = document.getElementById("emptyMsg");
    const searchInput = document.getElementById("searchUsuarios");
    const filterCargo = document.getElementById("filterCargo");
    const filterStatus = document.getElementById("filterStatus");
    const modalUsuario = document.getElementById("modalUsuario");
    const modalExcluir = document.getElementById("modalExcluir");
    const formUsuario = document.getElementById("formUsuario");
    const inputNome = document.getElementById("inputNome");
    const inputCargo = document.getElementById("inputCargo");
    const inputStatus = document.getElementById("inputStatus");
    const inputEmail = document.getElementById("inputEmail");
    const inputTelefone = document.getElementById("inputTelefone");
    const inputSenha = document.getElementById("inputSenha");
    const grupoCampoSenha = document.getElementById("grupoCampoSenha");
    const modalTitulo = document.getElementById("modalTitulo");

    if (isDiretor) {
        document.getElementById("pageSubtitle").textContent = "Gerencie cuidadores da unidade";
        document.getElementById("optAdministrador")?.remove();
        filterCargo.querySelector('option[value="administrador"]')?.remove();
    }

    let usuarios = [];
    let idEditando = null;
    let idExcluindo = null;

    async function carregarUsuarios() {
        try {
            const params = (!isDiretor && unidade.id) ? `?unidade_id=${unidade.id}` : "";
            usuarios = await apiFetch(`/api/usuarios${params}`);
            filtrar();
        } catch (err) {
            emptyMsg.textContent = err.message;
            emptyMsg.style.display = "block";
        }
    }

    function renderizarTabela(lista) {
        tbody.innerHTML = "";
        if (lista.length === 0) {
            emptyMsg.style.display = "block";
            return;
        }
        emptyMsg.style.display = "none";

        lista.forEach((u) => {
            const iniciais = u.nome.split(" ").slice(0, 2).map((p) => p[0]).join("").toUpperCase();
            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td>
                    <div class="user-cell">
                        <div class="user-avatar">${iniciais}</div>
                        <div>
                            <div class="user-cell-name">${u.nome}</div>
                            <div class="user-cell-email">${u.email}</div>
                        </div>
                    </div>
                </td>
                <td><span class="badge-cargo badge-${u.cargo}">${capitalizar(u.cargo)}</span></td>
                <td>${u.email}</td>
                <td>${u.telefone || "—"}</td>
                <td><span class="badge-status badge-${u.status}">${capitalizar(u.status)}</span></td>
                <td>
                    <div class="acoes-cell">
                        <button class="btn-acao btn-editar" data-id="${u.id}">Editar</button>
                        <button class="btn-acao btn-excluir" data-id="${u.id}">Excluir</button>
                    </div>
                </td>
            `;
            tr.querySelector(".btn-editar").addEventListener("click", () => abrirModalEdicao(u));
            tr.querySelector(".btn-excluir").addEventListener("click", () => abrirModalExcluir(u));
            tbody.appendChild(tr);
        });
    }

    function filtrar() {
        const texto = searchInput.value.toLowerCase().trim();
        const cargo = filterCargo.value;
        const status = filterStatus.value;
        const resultado = usuarios.filter((u) => {
            const bateTexto = u.nome.toLowerCase().includes(texto) || u.email.toLowerCase().includes(texto);
            const bateCargo = cargo === "" || u.cargo === cargo;
            const bateStatus = status === "" || u.status === status;
            return bateTexto && bateCargo && bateStatus;
        });
        renderizarTabela(resultado);
    }

    document.getElementById("btnNovoUsuario").addEventListener("click", () => {
        idEditando = null;
        modalTitulo.textContent = isDiretor ? "Novo Cuidador" : "Novo Usuário";
        formUsuario.reset();
        if (isDiretor) inputCargo.value = "cuidador";
        grupoCampoSenha.style.display = "flex";
        inputSenha.required = true;
        abrirModal(modalUsuario);
    });

    function abrirModalEdicao(u) {
        idEditando = u.id;
        modalTitulo.textContent = isDiretor ? "Editar Cuidador" : "Editar Usuário";
        inputNome.value = u.nome;
        inputCargo.value = u.cargo;
        inputStatus.value = u.status;
        inputEmail.value = u.email;
        inputTelefone.value = u.telefone || "";
        grupoCampoSenha.style.display = "none";
        inputSenha.required = false;
        inputSenha.value = "";
        abrirModal(modalUsuario);
    }

    formUsuario.addEventListener("submit", async (e) => {
        e.preventDefault();
        const dados = {
            nome: inputNome.value.trim(),
            cargo: inputCargo.value,
            status: inputStatus.value,
            email: inputEmail.value.trim(),
            telefone: inputTelefone.value.trim(),
        };

        if (isDiretor || unidade.id) {
            dados.unidade_id = unidade.id;
        }

        try {
            if (idEditando === null) {
                dados.senha = inputSenha.value;
                await apiFetch("/api/usuarios", { method: "POST", body: JSON.stringify(dados) });
            } else {
                if (inputSenha.value) dados.senha = inputSenha.value;
                await apiFetch(`/api/usuarios/${idEditando}`, { method: "PUT", body: JSON.stringify(dados) });
            }
            fecharModal(modalUsuario);
            await carregarUsuarios();
        } catch (err) {
            alert(err.message);
        }
    });

    function abrirModalExcluir(u) {
        idExcluindo = u.id;
        document.getElementById("nomeExcluir").textContent = u.nome;
        abrirModal(modalExcluir);
    }

    document.getElementById("btnConfirmarExcluir").addEventListener("click", async () => {
        try {
            await apiFetch(`/api/usuarios/${idExcluindo}`, { method: "DELETE" });
            idExcluindo = null;
            fecharModal(modalExcluir);
            await carregarUsuarios();
        } catch (err) {
            alert(err.message);
        }
    });

    document.getElementById("btnCancelarExcluir").addEventListener("click", () => fecharModal(modalExcluir));
    document.getElementById("btnFecharModal").addEventListener("click", () => fecharModal(modalUsuario));
    document.getElementById("btnCancelarModal").addEventListener("click", () => fecharModal(modalUsuario));

    window.addEventListener("click", (e) => {
        if (e.target === modalUsuario) fecharModal(modalUsuario);
        if (e.target === modalExcluir) fecharModal(modalExcluir);
    });

    inputTelefone.addEventListener("input", (e) => {
        let v = e.target.value.replace(/\D/g, "");
        v = v.replace(/^(\d{2})(\d)/g, "($1) $2");
        v = v.replace(/(\d{5})(\d)/, "$1-$2");
        e.target.value = v.substring(0, 15);
    });

    searchInput.addEventListener("input", filtrar);
    filterCargo.addEventListener("change", filtrar);
    filterStatus.addEventListener("change", filtrar);

    function abrirModal(modal) { modal.style.display = "flex"; }
    function fecharModal(modal) { modal.style.display = "none"; }

    await carregarUsuarios();
});
