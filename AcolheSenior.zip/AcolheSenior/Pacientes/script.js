document.addEventListener("DOMContentLoaded", async () => {
    const usuarioLogado = obterUsuario();
    const unidade = obterUnidadeAtual();
    const cargo = usuarioLogado.cargo || localStorage.getItem("cargoUsuario") || "";

    if (!unidade.id) {
        window.location.href = "/Home/index.HTML";
        return;
    }

    exibirNomeUsuario();
    configurarTema();
    configurarLogout();
    configurarSubNav();

    const podeEditarObs = ["diretor", "administrador"].includes(cargo);

    const cardsGrid = document.getElementById("cardsGrid");
    const emptyMsg = document.getElementById("emptyMsg");
    const modalPaciente = document.getElementById("modalPaciente");
    const fecharModal = document.getElementById("fecharModal");
    const listaObs = document.getElementById("listaObservacoes");
    const inputNovaObs = document.getElementById("novaObservacao");
    const btnAddObs = document.getElementById("btnAdicionarObs");
    const inputBusca = document.getElementById("searchPacientes");
    const filtroQuarto = document.getElementById("filterQuarto");
    const filtroTurno = document.getElementById("filterTurno");

    let pacienteAtivo = null;
    let pacientes = [];

    async function carregarFiltros() {
        try {
            const { quartos, turnos } = await apiFetch(`/api/pacientes/filtros?unidade_id=${unidade.id}`);
            quartos.forEach((q) => {
                const opt = document.createElement("option");
                opt.value = q;
                opt.textContent = q;
                filtroQuarto.appendChild(opt);
            });
            turnos.forEach((t) => {
                const opt = document.createElement("option");
                opt.value = t;
                opt.textContent = t;
                filtroTurno.appendChild(opt);
            });
        } catch { /* ignora */ }
    }

    async function carregarPacientes() {
        const params = new URLSearchParams({ unidade_id: unidade.id });
        const busca = inputBusca.value.trim();
        const quarto = filtroQuarto.value;
        const turno = filtroTurno.value;
        if (busca) params.set("busca", busca);
        if (quarto) params.set("quarto", quarto);
        if (turno) params.set("turno", turno);

        try {
            pacientes = await apiFetch(`/api/pacientes?${params}`);
            renderCards(pacientes);
        } catch (err) {
            emptyMsg.textContent = err.message;
            emptyMsg.style.display = "block";
        }
    }

    function fotoDefault(sexo) {
        return sexo === "Feminino" ? "paciente_feminino.png" : "paciente_masculino.png";
    }

    function renderCards(lista) {
        cardsGrid.innerHTML = "";
        emptyMsg.style.display = lista.length === 0 ? "block" : "none";
        if (lista.length === 0) {
            emptyMsg.textContent = "Nenhum paciente encontrado.";
            return;
        }

        lista.forEach((p) => {
            const foto = p.foto_path || fotoDefault(p.sexo);
            const card = document.createElement("div");
            card.className = `card ${p.sexo === "Feminino" ? "paciente-f" : "paciente-m"}`;
            card.innerHTML = `
                <div class="student-photo">
                    <img src="${foto}" alt="Foto Paciente" onerror="this.src='${fotoDefault(p.sexo)}'">
                </div>
                <div class="card-header">
                    <strong>${p.nome}</strong>
                    <span class="idade-badge">${p.idade}</span>
                </div>
                <div class="card-body">
                    <p><strong>Quarto:</strong> ${p.quarto || "—"}</p>
                    <p><strong>Turno:</strong> ${p.turno || "—"}</p>
                    <span class="tag-condicao">${p.condicoes_saude ? p.condicoes_saude.split(",")[0] : "—"}</span>
                </div>
                <div class="card-footer">
                    <p><em>${p.recomendacoes ? p.recomendacoes.substring(0, 50) + "..." : "Sem recomendações."}</em></p>
                </div>
                <div class="quick-obs">
                    <textarea class="quick-obs-input" placeholder="Observação rápida..."></textarea>
                    <button class="quick-obs-btn">Registrar</button>
                </div>
                <button class="btn-open-profile">Ver Perfil Completo</button>
            `;

            card.querySelector(".btn-open-profile").addEventListener("click", (e) => {
                e.stopPropagation();
                abrirModal(p.id);
            });

            card.querySelector(".quick-obs-btn").addEventListener("click", async (e) => {
                e.stopPropagation();
                const input = card.querySelector(".quick-obs-input");
                const texto = input.value.trim();
                if (!texto) { alert("Digite uma observação."); return; }
                try {
                    await apiFetch(`/api/pacientes/${p.id}/observacoes`, {
                        method: "POST",
                        body: JSON.stringify({ texto }),
                    });
                    input.value = "";
                    alert(`Observação registrada para ${p.nome}!`);
                } catch (err) {
                    alert(err.message);
                }
            });

            card.querySelector(".quick-obs-input").addEventListener("click", (e) => e.stopPropagation());
            cardsGrid.appendChild(card);
        });
    }

    async function abrirModal(id) {
        try {
            pacienteAtivo = await apiFetch(`/api/pacientes/${id}`);
            const p = pacienteAtivo;

            document.getElementById("modalFoto").src = p.foto_path || fotoDefault(p.sexo);
            document.getElementById("modalNome").textContent = p.nome;
            document.getElementById("modalIdade").textContent = p.idade;
            document.getElementById("modalMatricula").value = p.matricula || "—";
            document.getElementById("modalQuarto").value = p.quarto || "—";
            document.getElementById("modalTurno").value = p.turno || "—";
            document.getElementById("modalSexo").value = p.sexo || "—";
            document.getElementById("modalDataNasc").value = p.data_nascimento_fmt || "—";
            document.getElementById("modalCPF").value = p.cpf || "—";
            document.getElementById("modalRG").value = p.rg || "—";
            document.getElementById("modalCEP").value = p.cep || "—";
            document.getElementById("modalRua").value = p.rua || "—";
            document.getElementById("modalNumero").value = p.numero || "—";
            document.getElementById("modalComplemento").value = p.complemento || "—";
            document.getElementById("modalBairro").value = p.bairro || "—";
            document.getElementById("modalCidadeUF").value = `${p.cidade || ""} / ${p.estado || ""}`;
            document.getElementById("modalCondicoes").value = p.condicoes_saude || "—";
            document.getElementById("modalDependencia").value = p.grau_dependencia || "—";
            document.getElementById("modalMedicacoes").value = p.medicacoes || "—";
            document.getElementById("modalAlergias").value = p.alergias || "—";
            document.getElementById("modalPlanoSaude").value = p.plano_saude || "—";
            document.getElementById("modalMobilidade").value = p.mobilidade || "—";
            document.getElementById("modalRecomendacoes").value = p.recomendacoes || "—";
            document.getElementById("modalHistorico").value = p.historico_clinico || "—";

            const contatosEl = document.getElementById("modalContatos");
            if (p.contatos && p.contatos.length > 0) {
                contatosEl.innerHTML = p.contatos.map((c) => `
                    <div class="contato-item">
                        <strong>${c.nome}</strong> (${c.parentesco})<br>
                        <small>${c.telefone || "—"}</small>
                    </div>
                `).join("");
            } else {
                contatosEl.innerHTML = '<p style="font-size:13px; color:var(--text-muted);">Nenhum contato registrado.</p>';
            }

            renderObservacoes();
            modalPaciente.classList.add("active");
        } catch (err) {
            alert(err.message);
        }
    }

    function renderObservacoes() {
        listaObs.innerHTML = "";
        const obs = pacienteAtivo?.observacoes || [];

        if (obs.length === 0) {
            listaObs.innerHTML = '<p style="font-size:13px; color:var(--text-muted);">Nenhuma observação registrada ainda.</p>';
            return;
        }

        obs.forEach((o) => {
            const div = document.createElement("div");
            div.className = "obs-item";
            let meta = `Registrado por <strong>${o.criado_por}</strong> em ${formatarDataBR(o.criado_em)}`;
            if (o.editado_por) {
                meta += `<br>Editado por <strong>${o.editado_por}</strong> em ${formatarDataBR(o.editado_em)}`;
            }
            div.innerHTML = `<p>${o.texto}</p><small>${meta}</small>`;

            if (podeEditarObs) {
                const acoes = document.createElement("div");
                acoes.className = "obs-actions";
                acoes.innerHTML = `<button class="btn-edit">Editar</button><button class="btn-delete">Excluir</button>`;

                acoes.querySelector(".btn-edit").addEventListener("click", async () => {
                    const novoTexto = prompt("Editar observação:", o.texto);
                    if (!novoTexto || novoTexto.trim() === o.texto) return;
                    try {
                        await apiFetch(`/api/observacoes/${o.id}`, {
                            method: "PUT",
                            body: JSON.stringify({ texto: novoTexto.trim() }),
                        });
                        await abrirModal(pacienteAtivo.id);
                    } catch (err) { alert(err.message); }
                });

                acoes.querySelector(".btn-delete").addEventListener("click", async () => {
                    if (!confirm("Excluir esta observação?")) return;
                    try {
                        await apiFetch(`/api/observacoes/${o.id}`, { method: "DELETE" });
                        await abrirModal(pacienteAtivo.id);
                    } catch (err) { alert(err.message); }
                });

                div.appendChild(acoes);
            }
            listaObs.appendChild(div);
        });
    }

    btnAddObs.addEventListener("click", async () => {
        const texto = inputNovaObs.value.trim();
        if (!texto) { alert("Digite uma observação antes de adicionar."); return; }
        try {
            await apiFetch(`/api/pacientes/${pacienteAtivo.id}/observacoes`, {
                method: "POST",
                body: JSON.stringify({ texto }),
            });
            inputNovaObs.value = "";
            await abrirModal(pacienteAtivo.id);
        } catch (err) { alert(err.message); }
    });

    fecharModal.addEventListener("click", () => {
        modalPaciente.classList.remove("active");
        pacienteAtivo = null;
    });
    modalPaciente.addEventListener("click", (e) => {
        if (e.target === modalPaciente) {
            modalPaciente.classList.remove("active");
            pacienteAtivo = null;
        }
    });

    inputBusca.addEventListener("input", carregarPacientes);
    filtroQuarto.addEventListener("change", carregarPacientes);
    filtroTurno.addEventListener("change", carregarPacientes);

    await carregarFiltros();
    await carregarPacientes();
});
