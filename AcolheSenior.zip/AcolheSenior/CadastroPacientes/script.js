document.addEventListener("DOMContentLoaded", () => {
    const sectionContatos = document.getElementById("sectionContatos");
    const btnAdd = document.getElementById("addContato");
    const fotoUpload = document.getElementById("foto-upload");
    const fotoPreview = document.getElementById("foto-preview");
    const photoBox = document.getElementById("photo-box");
    const form = document.getElementById("formCadastro");
    const unidade = obterUnidadeAtual();

    if (!unidade.id) {
        window.location.href = "/Home/index.HTML";
        return;
    }

    exibirNomeUsuario();
    configurarTema();
    configurarLogout();
    configurarSubNav();

    function criarCamposContato() {
        const div = document.createElement("div");
        div.className = "responsavel-entry";
        div.innerHTML = `
            <div class="row">
                <select required class="parentesco-select">
                    <option value="">Parentesco</option>
                    <option>Filho(a)</option>
                    <option>Cônjuge</option>
                    <option>Irmão(ã)</option>
                    <option>Neto(a)</option>
                    <option>Outro</option>
                </select>
                <input type="text" placeholder="Nome do Contato" required class="grow contato-nome" maxlength="60">
                <input type="tel" placeholder="Telefone" required class="mask-tel contato-tel">
                <button type="button" class="btn-remove">×</button>
            </div>
            <div class="row">
                <input type="text" placeholder="CPF" class="mask-cpf contato-cpf" maxlength="14">
                <input type="text" placeholder="RG" class="mask-rg contato-rg" maxlength="12">
            </div>
        `;
        div.querySelector(".btn-remove").addEventListener("click", () => div.remove());
        aplicarMascaras(div);
        sectionContatos.appendChild(div);
    }

    function aplicarMascaras(container) {
        container.querySelectorAll(".mask-cpf").forEach((input) => {
            input.addEventListener("input", (e) => {
                let v = e.target.value.replace(/\D/g, "");
                v = v.replace(/(\d{3})(\d)/, "$1.$2");
                v = v.replace(/(\d{3})(\d)/, "$1.$2");
                v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
                e.target.value = v;
            });
        });
        container.querySelectorAll(".mask-rg").forEach((input) => {
            input.addEventListener("input", (e) => {
                let v = e.target.value.replace(/\D/g, "");
                v = v.replace(/(\d{2})(\d)/, "$1.$2");
                v = v.replace(/(\d{3})(\d)/, "$1.$2");
                v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
                e.target.value = v;
            });
        });
        container.querySelectorAll(".mask-tel").forEach((input) => {
            input.addEventListener("input", (e) => {
                let v = e.target.value.replace(/\D/g, "");
                v = v.replace(/^(\d{2})(\d)/g, "($1) $2");
                v = v.replace(/(\d{5})(\d)/, "$1-$2");
                e.target.value = v.substring(0, 15);
            });
        });
        container.querySelectorAll(".mask-cep").forEach((input) => {
            input.addEventListener("input", (e) => {
                let v = e.target.value.replace(/\D/g, "");
                v = v.replace(/(\d{5})(\d)/, "$1-$2");
                e.target.value = v.substring(0, 9);
            });
        });
    }

    if (fotoUpload) {
        fotoUpload.addEventListener("change", function () {
            const arquivo = this.files[0];
            const photoText = document.getElementById("photo-text");
            if (arquivo) {
                const leitor = new FileReader();
                leitor.onload = (e) => {
                    fotoPreview.src = e.target.result;
                    fotoPreview.style.display = "block";
                    photoText.style.display = "none";
                    photoBox.style.borderStyle = "solid";
                };
                leitor.readAsDataURL(arquivo);
                photoBox.classList.remove("missing");
            }
        });
    }

    btnAdd.addEventListener("click", criarCamposContato);
    criarCamposContato();
    aplicarMascaras(document);

    document.getElementById("cep").addEventListener("blur", async () => {
        const cep = document.getElementById("cep").value.replace(/\D/g, "");
        if (cep.length !== 8) return;
        try {
            const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const dados = await resposta.json();
            if (dados.erro) { alert("CEP não encontrado."); return; }
            document.getElementById("rua").value = dados.logradouro || "";
            document.getElementById("bairro").value = dados.bairro || "";
            document.getElementById("cidade").value = dados.localidade || "";
            document.getElementById("estado").value = dados.uf || "";
        } catch {
            alert("Erro ao buscar o CEP.");
        }
    });

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        if (fotoUpload.files.length === 0) {
            photoBox.classList.add("missing");
            alert("A foto do paciente é obrigatória!");
            return;
        }

        const contatos = [];
        sectionContatos.querySelectorAll(".responsavel-entry").forEach((entry) => {
            contatos.push({
                parentesco: entry.querySelector(".parentesco-select").value,
                nome: entry.querySelector(".contato-nome").value,
                telefone: entry.querySelector(".contato-tel").value,
                cpf: entry.querySelector(".contato-cpf").value,
                rg: entry.querySelector(".contato-rg").value,
            });
        });

        let foto_path = null;
        if (fotoUpload.files[0]) {
            foto_path = await new Promise((resolve) => {
                const reader = new FileReader();
                reader.onload = (ev) => resolve(ev.target.result);
                reader.readAsDataURL(fotoUpload.files[0]);
            });
        }

        const payload = {
            matricula: document.getElementById("matricula").value,
            nome: document.getElementById("nome").value,
            cpf: document.getElementById("cpf").value,
            rg: document.getElementById("rg").value,
            data_nascimento: document.getElementById("dataNascimento").value,
            sexo: document.getElementById("sexo").value,
            quarto: document.getElementById("quarto").value,
            turno: document.getElementById("turno").value,
            cep: document.getElementById("cep").value,
            rua: document.getElementById("rua").value,
            numero: document.getElementById("numero").value,
            complemento: document.getElementById("complemento").value,
            bairro: document.getElementById("bairro").value,
            cidade: document.getElementById("cidade").value,
            estado: document.getElementById("estado").value,
            foto_path,
            condicoes_saude: document.getElementById("condicoesSaude").value,
            grau_dependencia: document.getElementById("grauDependencia").value,
            medicacoes: document.getElementById("medicacoes").value,
            alergias: document.getElementById("alergias").value,
            plano_saude: document.getElementById("planoSaude").value,
            mobilidade: document.getElementById("mobilidade").value,
            recomendacoes: document.getElementById("recomendacoes").value,
            historico_clinico: document.getElementById("historicoClinico").value,
            unidade_id: unidade.id,
            contatos,
        };

        try {
            await apiFetch("/api/pacientes", {
                method: "POST",
                body: JSON.stringify(payload),
            });
            alert("Paciente cadastrado com sucesso!");
            window.location.href = "/Pacientes/index.HTML";
        } catch (err) {
            alert(err.message);
        }
    });
});
