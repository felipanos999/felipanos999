const API_BASE = "";

async function apiFetch(url, options = {}) {
  const res = await fetch(`${API_BASE}${url}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.erro || "Erro na requisição.");
  }

  return data;
}

function salvarUsuario(usuario) {
  localStorage.setItem("usuarioLogado", JSON.stringify(usuario));
  localStorage.setItem("nomeUsuario", usuario.nome);
  localStorage.setItem("cargoUsuario", usuario.cargo);
}

function obterUsuario() {
  try {
    return JSON.parse(localStorage.getItem("usuarioLogado") || "{}");
  } catch {
    return {};
  }
}

function obterUnidadeAtual() {
  try {
    return JSON.parse(localStorage.getItem("unidadeAtual") || "{}");
  } catch {
    return {};
  }
}

function capitalizar(str) {
  if (!str) return "";
  const map = {
    diretor: "Diretor",
    administrador: "Administrador",
    cuidador: "Cuidador",
    ativo: "Ativo",
    inativo: "Inativo",
  };
  return map[str] || str.charAt(0).toUpperCase() + str.slice(1);
}

function configurarTema() {
  const themeToggle = document.getElementById("theme-toggle");
  const iconLua = document.getElementById("theme-icon-dark");
  const iconSol = document.getElementById("theme-icon-light");

  function atualizarIcone(isDark) {
    if (iconLua) iconLua.style.display = isDark ? "none" : "block";
    if (iconSol) iconSol.style.display = isDark ? "block" : "none";
  }

  if (localStorage.getItem("theme") === "dark") {
    document.documentElement.setAttribute("data-theme", "dark");
    atualizarIcone(true);
  }

  themeToggle?.addEventListener("click", () => {
    const isDark = document.documentElement.getAttribute("data-theme") === "dark";
    if (isDark) {
      document.documentElement.removeAttribute("data-theme");
      localStorage.setItem("theme", "light");
      themeToggle.title = "Alternar para modo escuro";
    } else {
      document.documentElement.setAttribute("data-theme", "dark");
      localStorage.setItem("theme", "dark");
      themeToggle.title = "Alternar para modo claro";
    }
    atualizarIcone(!isDark);
  });
}

function configurarLogout() {
  document.getElementById("btnLogout")?.addEventListener("click", async () => {
    if (!confirm("Tem certeza que deseja sair?")) return;
    try {
      await apiFetch("/api/auth/logout", { method: "POST" });
    } catch { /* ignora erro no logout */ }
    localStorage.clear();
    window.location.href = "/Login/index.HTML";
  });
}

function exibirNomeUsuario() {
  const nome = localStorage.getItem("nomeUsuario");
  document.querySelectorAll(".user-name").forEach((el) => {
    if (nome) el.textContent = nome;
  });
}

function configurarSubNav() {
  const cargo = localStorage.getItem("cargoUsuario") || "";
  const subNav = document.getElementById("subNav");
  if (subNav && ["diretor", "administrador"].includes(cargo)) {
    subNav.style.display = "flex";
  }
}

function formatarDataBR(iso) {
  if (!iso) return "—";
  const d = new Date(iso.includes("T") ? iso : iso.replace(" ", "T"));
  if (isNaN(d)) {
    const [y, m, day] = iso.split("-");
    return day ? `${day}/${m}/${y}` : iso;
  }
  return d.toLocaleString("pt-BR");
}
